// 'use strict';

function AuthHelper(callback) {

    var cb = callback;
    var can_auth = true;

    // callback = function(bool success, object error)
    this.logout = function (callback) {
        if (Settings.AccessToken) {
            var revokeUrl = 'https://accounts.google.com/o/oauth2/revoke?token=' + Settings.AccessToken;

            // Perform an asynchronous GET request.
            $.ajax({
                type: 'GET',
                url: revokeUrl,
                async: false,
                contentType: "application/json",
                dataType: 'jsonp',
                success: function (nullResponse) {
                    callback && callback(true, null);
                },
                error: function (e) {
                    callback && callback(false, e);
                }
            });
        }
        else {
            callback && callback(false, null);
        }
    };


    var handleAuthResult = function (authResult) {

        if (authResult && !authResult.error) {
            Settings.AccessToken = authResult.access_token;
            cb && cb();
        } else {
            if (can_auth) {
                can_auth = false;

                gapi.auth.authorize(
                    { 'client_id': Settings.ClientID, 'scope': Settings.Scopes, 'immediate': false },
                    handleAuthResult);
            }
            else {
                alert(authResult.error);
                Settings.AccessToken = null;
                cb && cb();
            }
        }
    };

    var checkAuth = function () {
        gapi.auth.authorize(
            { 'client_id': Settings.ClientID, 'scope': Settings.Scopes, 'immediate': true },
            handleAuthResult
            );
    };


    var retry = true;
    var url = 'https://content.googleapis.com/drive/v2/about?key=';

    var getToken = function () {
        try {
            alert('auth-2');
            chrome.identity.getAuthToken({ 'interactive': true }, function (token) {
                alert('auth-3');
                if (chrome.runtime.lastError) {
                    alert(chrome.runtime.lastError);
                    console.debug(chrome.runtime.lastError);
                } else {
                    alert(token);
                    Settings.AccessToken = token;
                    // gapi.auth.setToken(token);
                    cb && cb();
                    // requestStart();
                }
            });
        }
        catch(ex)
        {
            alert(ex);
        }
    }

    function requestStart() {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url + Settings.ApiKey);
        xhr.setRequestHeader('Authorization', 'Bearer ' + Settings.AccessToken);
        xhr.onload = requestComplete;
        xhr.send();
    }

    function requestComplete(progressEvent) {
        // console.log(progressEvent);
        if (progressEvent.target.status == 401 && retry) {
            retry = false;
            chrome.identity.removeCachedAuthToken({ token: Settings.AccessToken }, getToken);
        } else {
            cb && cb();
        }
    }

    var constructor = function () {
        alert('auth-1');
        // gapi.client.setApiKey(Settings.ApiKey);
        checkAuth();
        getToken();
    };

    constructor();
}
