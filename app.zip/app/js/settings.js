﻿'use strict';

var Settings = {

    // Client ID for Chrome application
    // CLIENT ID
    ClientID: "458531844515-8aohg5151k1gdmfbt5762dpjcc25g9e9.apps.googleusercontent.com",

    // Key for browser applications
    // API KEY
    ApiKey: "AIzaSyAAdwcBLfjclphcokapqnSEEp2PX6Y6la0",

    AccessToken: null,

    Scopes: [
        'https://www.googleapis.com/auth/drive'
    ]
}
